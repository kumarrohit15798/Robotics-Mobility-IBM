% ==============================================================
% utility function for packing/unpacking/passing data
% ==============================================================
function [m,I,k,len0,g,b] = unpackParams(params)
    m    = params.m;
    I    = params.I;
    k    = params.k;
    len0 = params.len0;
    g    = params.g;
    b    = params.b;
end