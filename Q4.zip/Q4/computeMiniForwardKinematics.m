function [endeff] = computeMiniForwardKinematics(rads1,rads2)

endeff = [0,0];