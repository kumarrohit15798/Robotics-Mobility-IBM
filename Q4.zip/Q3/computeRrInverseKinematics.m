function [rads1,rads2] = computeRrInverseKinematics(X,Y)

syms theta1 theta2 ;

rads1=0;
rads2=0;