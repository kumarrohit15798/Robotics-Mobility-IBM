function endeff = computeForwardKinematics(rads)



x = 0;
y = 0;


endeff = [x,y];

